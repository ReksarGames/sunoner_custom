#include "detection_buffer.h"

DetectionBuffer detectionBuffer;