﻿// HIDConnection.h
#pragma once

#include <cstdint>
#include <memory>

#include "MouseInstruct.h"

class HIDConnection {
public:
    // Указываем только VID и PID, pingCode возьмётся по-дефолту внутри MouseInstruct.
    HIDConnection(uint16_t vid, uint16_t pid);
    ~HIDConnection();

    // Методы управления мышью
    void move(int8_t x, int8_t y);
    void click();
    void press();
    void release();

    bool isOpen() const;

private:
    // храним единственный готовый объект для отправки команд
    std::unique_ptr<MouseInstruct> mouse_;
};
