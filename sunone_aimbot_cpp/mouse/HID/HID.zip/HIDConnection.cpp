// HIDConnection.cpp
#include "HIDConnection.h"
#include <iostream>
#include <stdexcept>

HIDConnection::HIDConnection(uint16_t vid, uint16_t pid) {
    try {
        // Один раз открываем устройство (pingCode берётся из дефолта MouseInstruct)
        mouse_ = std::make_unique<MouseInstruct>(
            MouseInstruct::getMouse(vid, pid)
        );
        std::cout << "HID-устройство успешно открыто\n";
    }
    catch (const DeviceNotFoundException& e) {
        std::cerr << "Не удалось найти HID-устройство: " << e.what() << "\n";
        // mouse_ останется nullptr, isOpen() даст false
    }
}

HIDConnection::~HIDConnection() = default;

bool HIDConnection::isOpen() const {
    return static_cast<bool>(mouse_);
}

void HIDConnection::move(int8_t x, int8_t y) {
    if (!mouse_) throw std::runtime_error("Устройство не открыто");
    mouse_->move(x, y);
}

void HIDConnection::click() {
    if (!mouse_) throw std::runtime_error("Устройство не открыто");
    mouse_->click();
}

void HIDConnection::press() {
    if (!mouse_) throw std::runtime_error("Устройство не открыто");
    mouse_->press();
}

void HIDConnection::release() {
    if (!mouse_) throw std::runtime_error("Устройство не открыто");
    mouse_->release();
}
