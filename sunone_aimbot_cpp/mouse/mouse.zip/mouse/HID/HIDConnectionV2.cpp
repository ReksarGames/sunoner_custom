﻿#include "HidConnectionV2.h"
#include <windows.h>
#include <setupapi.h>
#include <initguid.h>
#include <hidsdi.h>
#include <usbiodef.h>
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>

static bool PathMatchesVidPid(const std::wstring& path, uint16_t vid, uint16_t pid)
{
    auto vidPos = path.find(L"vid_");
    auto pidPos = path.find(L"pid_");
    if (vidPos == std::wstring::npos || pidPos == std::wstring::npos)
        return false;

    uint16_t pathVid = static_cast<uint16_t>(
        wcstoul(path.substr(vidPos + 4, 4).c_str(), nullptr, 16));
    uint16_t pathPid = static_cast<uint16_t>(
        wcstoul(path.substr(pidPos + 4, 4).c_str(), nullptr, 16));

    return pathVid == vid && pathPid == pid;
}

HidConnectionV2::HidConnectionV2(uint16_t vid, uint16_t pid)
{
    // 1) GUID HID
    GUID hidGuid;
    HidD_GetHidGuid(&hidGuid);

    // 2) Список HID-интерфейсов
    HDEVINFO devInfo = SetupDiGetClassDevsW(
        &hidGuid, nullptr, nullptr,
        DIGCF_PRESENT | DIGCF_DEVICEINTERFACE
    );
    if (devInfo == INVALID_HANDLE_VALUE)
        throw std::runtime_error("HidConnectionV2: не удалось получить список HID-интерфейсов");

    SP_DEVICE_INTERFACE_DATA ifData{};
    ifData.cbSize = sizeof(ifData);
    DWORD idx = 0;
    bool found = false;

    // 3) Перебираем все интерфейсы
    while (SetupDiEnumDeviceInterfaces(devInfo, nullptr, &hidGuid, idx++, &ifData))
    {
        DWORD reqSize = 0;
        SetupDiGetDeviceInterfaceDetailW(devInfo, &ifData, nullptr, 0, &reqSize, nullptr);

        std::vector<BYTE> buf(reqSize);
        auto detail = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA_W*>(buf.data());
        detail->cbSize = sizeof(*detail);
        if (!SetupDiGetDeviceInterfaceDetailW(devInfo, &ifData, detail, reqSize, nullptr, nullptr))
            continue;

        std::wstring path(detail->DevicePath);
        if (!PathMatchesVidPid(path, vid, pid))
            continue;

        HANDLE h = CreateFileW(
            path.c_str(),
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_EXISTING,
            FILE_FLAG_OVERLAPPED,
            nullptr
        );
        if (h == INVALID_HANDLE_VALUE)
            continue;

        PHIDP_PREPARSED_DATA ppd = nullptr;
        if (!HidD_GetPreparsedData(h, &ppd)) { CloseHandle(h); continue; }
        HIDP_CAPS caps{};
        if (HidP_GetCaps(ppd, &caps) != HIDP_STATUS_SUCCESS) {
            HidD_FreePreparsedData(ppd);
            CloseHandle(h);
            continue;
        }
        HidD_FreePreparsedData(ppd);

        if (caps.OutputReportByteLength >= sizeof(RawHIDPacket64) + 1) {
            outputReportLength_ = caps.OutputReportByteLength;
            useOutput_ = true;
        }
        else if (caps.FeatureReportByteLength >= sizeof(RawHIDPacket64) + 1) {
            featureReportLength_ = caps.FeatureReportByteLength;
            useFeature_ = true;
        }

        if (!useOutput_ && !useFeature_) {
            CloseHandle(h);
            continue;
        }

        device_ = h;
        found = true;
        break;
    }

    SetupDiDestroyDeviceInfoList(devInfo);
    if (!found)
        throw std::runtime_error("HidConnectionV2: нужный интерфейс не найден");
}

HidConnectionV2::~HidConnectionV2()
{
    if (device_ != INVALID_HANDLE_VALUE)
        CloseHandle(device_);
}

void HidConnectionV2::move(int8_t x, int8_t y)
{
    RawHIDPacket64 packet{};
    packet.dx = x;
    packet.dy = y;
    sendRawHID(packet);
}

void HidConnectionV2::click()
{
    press();
    release();
}

void HidConnectionV2::press()
{
    RawHIDPacket64 packet{};
    packet.buttons = 1;
    sendRawHID(packet);
    currentButtons_ = packet.buttons;
}

void HidConnectionV2::release()
{
    RawHIDPacket64 packet{};
    sendRawHID(packet);
    currentButtons_ = 0;
}

void HidConnectionV2::sendRawHID(const RawHIDPacket64& packet)
{
    std::lock_guard<std::mutex> lock(writeMutex_);

    if (useOutput_) {
        std::vector<BYTE> report(outputReportLength_);
        report[0] = 1;  // REPORT_ID
        memcpy(report.data() + 1, &packet, sizeof(packet));

        OVERLAPPED ov = {};
        ov.hEvent = CreateEvent(nullptr, FALSE, FALSE, nullptr);

        DWORD written = 0;
        if (!WriteFile(device_, report.data(), (DWORD)report.size(), &written, &ov)) {
            if (GetLastError() == ERROR_IO_PENDING) {
                GetOverlappedResult(device_, &ov, &written, TRUE);
            }
            else {
                CloseHandle(ov.hEvent);
                throw std::runtime_error("HidConnectionV2: не удалось отправить OutputReport");
            }
        }
        CloseHandle(ov.hEvent);
    }
    else {
        std::vector<BYTE> report(featureReportLength_);
        report[0] = 1;
        memcpy(report.data() + 1, &packet, sizeof(packet));

        if (!HidD_SetFeature(device_, report.data(), (ULONG)report.size())) {
            throw std::runtime_error("HidConnectionV2: не удалось отправить FeatureReport");
        }
    }
}
